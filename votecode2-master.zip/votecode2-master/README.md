# votecode2
This is where the VoteCode goes! 
Here are some of the libraries and packages I recommend downloading before getting started:

pyler, stringr for help with data wrangling/cleaning
ggplot2 for data visualization
reticulate for opening a python session in R
caret, nnet for predictive modeling 

The first decision was to write a python script to parse the addresses since it's the language I am the most familiar with. The second part was to use R and packages within R to begin building the predictive model. 

I could not finish developing the predictive model in time. I was able to put together bits and pieces of what I was working on - as noted by the different named parts. 

For automating tests - I have begun looking into an R package called testthat that helps to build automated tests for data sets. 

For running the python script, you can load r-reticulate into R in order to create a python session within R to be able to run the script. 
